﻿using System;
using System.Collections.Generic;
using HelloWorldApp.Controllers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HelloWorldApp.Tests.Controllers
{
	[TestClass]
	public class HelloWorldControllerTest
	{
		[TestMethod]
		public void Get()
		{
			//Assert.AreEqual("HelloWorldController", "HelloWorldController");

			// Arrange
			HelloWorldController controller = new HelloWorldController();

			// Act
			string result = controller.Get();

			// Assert
			Assert.IsNotNull(result);
		}
	}
}
