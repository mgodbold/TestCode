﻿using System.Collections.Generic;
using BusinessEntities;

namespace BusinessServices
{
	public interface IProductServices
	{
		string getData();
	}
}
