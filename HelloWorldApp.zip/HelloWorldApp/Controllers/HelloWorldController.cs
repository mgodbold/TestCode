﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BusinessEntities;
using BusinessServices;


namespace HelloWorldApp.Controllers
{
    public class HelloWorldController : ApiController
    {
		private readonly IProductServices _productServices;

		public HelloWorldController()
		{
			_productServices = new ProductServices();
		}
		
		public string Get()
		{
			var val = _productServices.getData();
			return val;

			//return "Hello World";
		}
    }
}
