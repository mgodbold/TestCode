﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;

namespace HelloWorldConsole
{
	class Program
	{
		static void Main(string[] args)
		{
			using (var client = new HttpClient())
			{
				client.BaseAddress = new Uri("http://localhost:55948/");
				client.DefaultRequestHeaders.Accept.Clear();
				client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
				APIGet(client).Wait();
			}
		}

		static async Task APIGet(HttpClient client)
		{
			var response = await client.GetAsync("api/HelloWorld/");
			response.EnsureSuccessStatusCode();
			if (response.IsSuccessStatusCode)
			{
				var result = await response.Content.ReadAsStringAsync();
				Console.Write(result);
				Console.ReadLine();
			}
		}
	}
}
